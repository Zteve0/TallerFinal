#!/bin/bash

apt update
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh ./get-docker.sh
apt install docker-compose -y
docker build -t micro1:v1.0 /home/ubuntu/Aplicacion/ms1/
docker build -t micro2:v1.0 /home/ubuntu/Aplicacion/ms2/
#docker-compose up -d
sudo docker run -d -p 5555:5555 --name micro1 micro1:v1.0 
sudo docker run -d -p 5556:5556 --name micro2 micro2:v1.0 